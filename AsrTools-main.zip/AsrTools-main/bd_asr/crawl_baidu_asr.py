import json
import os
from urllib.parse import quote

import requests
from oslash.util.numerals import apply



def custom_url_encode(url):
    # 这里的safe参数表示不进行编码的字符，默认为'/', 我们将其移除
    return quote(url, safe='')


def getList(dir,save_path,folder_name):
    encoded_dir = custom_url_encode(dir)
    url = "https://pan.baidu.com/api/list?clienttype=0&app_id=250528&web=1&dp-logid=18464300773267300041&order=time&desc=1&dir="+encoded_dir+"&num=100&page=1"

    payload = {}
    headers = {
        'cookie': 'PANWEB=1; BIDUPSID=EF612286A5F0FE995B2CE2BBCD2182B8; PSTM=1728153441; H_PS_PSSID=60842; csrfToken=8vz3pppdqRRECaonvvOd-ZIF; Hm_lvt_7a3960b6f067eb0085b7f96ff5e660b0=1728068132,1728152279,1728159388,1728298384; HMACCOUNT=FF6741441945F4D6; ppfuid=FOCoIC3q5fKa8fgJnwzbE67EJ49BGJeplOzf+4l4EOvDuu2RXBRv6R3A1AZMa49I27C0gDDLrJyxcIIeAeEhD8JYsoLTpBiaCXhLqvzbzmvy3SeAW17tKgNq/Xx+RgOdb8TWCFe62MVrDTY6lMf2GrfqL8c87KLF2qFER3obJGkdximGddNRzN/k8jMV5fwkGEimjy3MrXEpSuItnI4KD5D2jfuh+RInKG5l8qaOcCtR4EaoY7dI60LOhq0HnLAJjYJfQxS6ZeJem/A3CmAQtQkCbDM23TdA0CXmF0zgX4nGgLbz7OSojK1zRbqBESR5Pdk2R9IA3lxxOVzA+Iw1TWLSgWjlFVG9Xmh1+20oPSbrzvDjYtVPmZ+9/6evcXmhcO1Y58MgLozKnaQIaLfWRPAn9I0uOqAMff6fuUeWcH1mRYoTw2Nhr4J4agZi377iM/izL6cVCGRy2F8c0VpEvM5FjnYxYstXg/9EfB3EVmKAfzNRIeToJ5YV9twMcgdmlV1Uhhp5FAe6gNJIUptp7EMAaXYKm11G+JVPszQFdp9AJLcm4YSsYUXkaPI2Tl66J246cmjWQDTahAOINR5rXR5r/7VVI1RMZ8gb40q7az7vCK56XLooKT5a+rsFrf5Zu0yyCiiagElhrTEOtNdBJJq8eHwEHuFBni9ahSwpC7lbKkUwaKH69tf0DFV7hJROiLETSFloIVkHdy3+I2JUr1LsplAz0hMkWt/tE4tXVUV7QcTDTZWS/2mCoS/GV3N9awQ6iM6hs/BWjlgnEa1+5ssf+fVAEjZq78FsoWKI6FtArPGZq4pTbB5yDX64xsCh5FKazXcZ/j40FJv+iLGBn3nkkgHlne61I8I7KhtQgInO+h/JZ0N0QjxKNc+B6y+T0HyFyA/vZBxZgfLxDiIQ8h6mBkwApF76140uEbToi6c1kr4KVCZkVtSVOSeFLERPcI/SDFn7X/Kfhz990eKSC4IfXmZKhbrqojV32wcFNmIPvSWeHncTPON0OcZ3UW0ThlWBfBdYUs68Bfjfet0oTRjv5ii+uLg9FdQTz76laHhgWa2XYnL0I/yMaYOB1fXv8cSTQyUvg5bG6rt5+COubpDRly8hJJQuMhC7lnfy1nB/byDVtojV8VzprVRC2O+E8cSTQyUvg5bG6rt5+COubomTY4K0wDrt8OFFV508V7i9BTP7hct8v25t214g385XJlf9dI0aUTGtVnNNQzVUXc1QMqfijXctbnEZ7TrrD4Od0sIeyq9R1gs4TMyBREN1+COzqWiD/J/i86HI7d4aVw==; BDUSS=hwflUzVUpVN0tpU0hmTnZmR1N-eGd2dHl-WEtUNkhJVUQ3S3lOT2RtbklTeXRuSVFBQUFBJCQAAAAAAAAAAAEAAAAe2xpYdGFuanh0YW43NTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMi-A2fIvgNnUl; BDUSS_BFESS=hwflUzVUpVN0tpU0hmTnZmR1N-eGd2dHl-WEtUNkhJVUQ3S3lOT2RtbklTeXRuSVFBQUFBJCQAAAAAAAAAAAEAAAAe2xpYdGFuanh0YW43NTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMi-A2fIvgNnUl; STOKEN=b101dfc033c9cc886d1e787cda1be30ecab317ad417569c895e07a109d8bd280; BAIDU_WISE_UID=wapp_1728299441604_898; ZFY=M1nTXVqJ9vul5eSCfFUzN:A1JPzz38wOXUyKD8xHVm9w:C; BDCLND=AZKEJ8%2FrXec8ZOhOAK2crIdQVEIAw8St0zT8Fh8xfmw%3D; Hm_lpvt_7a3960b6f067eb0085b7f96ff5e660b0=1728392391; ndut_fmt=8FC7AB98BE6BB96AD4646939E4DB7EC8B2193E367AEEF8C01E2FD983AC05E8B1; Hm_lvt_d5bdc9eee733100f7b952fc44f7e53e4=1728392439; Hm_lpvt_d5bdc9eee733100f7b952fc44f7e53e4=1728392439; BAIDUID=60511BB965CD74EEF3B8F86990CFF48E:FG=1; BAIDUID_BFESS=60511BB965CD74EEF3B8F86990CFF48E:FG=1; PANPSC=14298758705909025473%3APBu5R64BDn0qeQWQHZaUu1cS2d9ns3O5fCX%2Fmi0NU5Ar1DUGfpqaPgjHRUw%2FZR6kz81ttRoL0tCAzpMjKfHvSs13uoxWjWPiY94v6bOg3aptcQe%2BbgwEaTXkEObzs8aRW8pfgMw2m%2FoUcUE8AeNtMbHTr8hPP552FkiozBc0GgDJ9uHMzNUFUYyRmZhDreWRdRr%2BYfIir8%2BVGpM9DhmBsS6zgY2%2BjnIxkrFWWqsgPEw%3D; BAIDUID=E27BA7519BBF3D74C6B6B975214BF525:FG=1; BAIDUID_BFESS=E27BA7519BBF3D74C6B6B975214BF525:FG=1; PANPSC=4837836956742010883%3APBu5R64BDn1MfGx%2FULpkHlcS2d9ns3O5fCX%2Fmi0NU5Ar1DUGfpqaPgjHRUw%2FZR6kz81ttRoL0tCAzpMjKfHvSs13uoxWjWPiY94v6bOg3aptcQe%2BbgwEaTXkEObzs8aRW8pfgMw2m%2FrhzGIjznB8Pd4Xpx6rjYdD0jtnBLnyK9d7t%2B9ObL%2BIzW3YtMdvXl6norVRx%2Fa05s%2BR2hdKZmRHyATwmM1z8l0ikrFWWqsgPEw%3D'
    }

    response = requests.request("GET", url, headers=headers, data=payload)

    json_data = json.loads(response.text)
    items = json_data['list']
    for item in items:
        print(item['server_filename'])
        print(item['path'])
        print(item['fs_id'])
        apply(item['fs_id'],item['path'],item['server_filename'].split('.')[0],save_path,folder_name)


def apply(fs_id,file_path,file_name,save_path,folder_name):
    url = "https://pan.baidu.com/richsearch/autosubtitle/common?method=apply&fsid="+str(fs_id)+"&share_uk=3680260293&client_type=2&from=2&clienttype=0&app_id=250528&web=1&channel=chunlei&dp-logid=48399400489844600001&logid=MDRGNDIxNzY2OTJGODM2NDgwRDRDMzhCMkI1Q0JBREU6Rkc9MQ%3D%3D"

    payload = {}
    headers = {

        'Cookie': 'csrfToken=5M01VlShedVdPtQCMvKz97xd; BAIDUID=04F42176692F836480D4C38B2B5CBADE:FG=1; BAIDUID_BFESS=04F42176692F836480D4C38B2B5CBADE:FG=1; newlogin=1; ppfuid=FOCoIC3q5fKa8fgJnwzbE67EJ49BGJeplOzf+4l4EOvDuu2RXBRv6R3A1AZMa49I27C0gDDLrJyxcIIeAeEhD8JYsoLTpBiaCXhLqvzbzmvy3SeAW17tKgNq/Xx+RgOdb8TWCFe62MVrDTY6lMf2GrfqL8c87KLF2qFER3obJGlgR5ugvPeCMvXkTGuVqi9VGEimjy3MrXEpSuItnI4KD/Ga8DcW2V0+9FvwpgBPLhwcG4LQZscCXnsZMrwtZfdxdo1bSe+HrPqGx0UlA4PdtxJsVwXkGdF24AsEQ3K5XBbh9EHAWDOg2T1ejpq0s2eFy9ar/j566XqWDobGoNNfmfpaEhZpob9le2b5QIEdiQez0E9SVndeXkd9EampG0PcXhLZ126CPFCIEuj/nWa+RCvURLVm4bpFOvBv8e58/dDOXSxFWocn8LvXoXRLp3fo5/fbkvdNVYtfeSgcfqcJz7tVNIB9KqyLqpAKG/6PN5nHZFO3SaB4GS7zlBrG2cLm8lTRl19JYcYcqvy3P/50mxpWDwUUC4pvKOF9e+pwNq7l6HzKEZyCMUDd+W6AiaksYiu+4AAz72OnMQfgAyNUbW3IyzL5c+UBht87WUigOY9alcIuR+n1gwn+Dmf3unATYGtv0zKmAog3Ny9wFYiQ/iTCRf3pI4Je1JeNfTzn6XDJZ8Wnjrf/q6TO2bHj5OH24qMgC25gHAxbb/tmQCApEKktJ7CISS0STF94GtUDhRi+72Y/TlJorI8GddU1XzO2O5htkQ9eW+/TVvYXwm0Xd4FIasM3e4G55WFWk5LZRFJNetS6mrAjm2GHsp1aRoBwYzuPaitSx6iW9pOhUZpcjM0Zi+3QrJ+6wvOYvuUOl+A3czNho4/J7j4tBR5DjQtGctmwW/4QqWoxJcNJq8kQzCzwv/fcUl9euhuED/o6m2iVpX0cU4NHwEy/Bqr1kOP1AxyNZHhQVZ2Gp0uL7HNFb+K+jseqgkgNhlYW3G8vU2dGT/8PDdrVN+aMZbHqtS1oD7ul7bRoEgw96s3k/oqBkZVYaMKnX0dWh5E7VnhqRSIp26nF1P0+H9oSyCPQ94PPS//7ugV0/jdYfz/I1urf18mpADR7ExSsg7XRAP5KtKewDFlxCPRBUDxiSr9CI6av6YpcYTnE0hbwjD92IjSd0RHf+nCu+VOrmHAISaUGzAJ/DJesRcpZiTyOfvO7GAwL1dzSAkzWXcpm+ZsJX3HKbA9mEBrXtMGp9ojg0Q3uD1I=; BDUSS=TRyZVBQSHpuZXhJanJkc01vVX4tazNNdGFDYUdNdHdhSDN4UVY1VzJNSjkwaXhuSVFBQUFBJCQAAAAAAAAAAAEAAAAe2xpYdGFuanh0YW43NTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH1FBWd9RQVnW; BDUSS_BFESS=TRyZVBQSHpuZXhJanJkc01vVX4tazNNdGFDYUdNdHdhSDN4UVY1VzJNSjkwaXhuSVFBQUFBJCQAAAAAAAAAAAEAAAAe2xpYdGFuanh0YW43NTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH1FBWd9RQVnW; STOKEN=202db0d3239284d5a1b7ffe814dcaba677d653fbb57620b7908e148a1abfa631; Hm_lvt_d5bdc9eee733100f7b952fc44f7e53e4=1728398723; ndut_fmt=5AB89AA27E6A5680072BB12C6BF8678CCB5EA002EEC474DC65B59553A8C96095; ab_sr=1.0.1_YzVjOTlmOTAzMTY2ZGI5OGQ5NDJiYzFjYzk0Yjk1YzhiY2NlYjBkYTY4OGYxYTA1MDEyMjQwOTQ1NTUwODljNzVlYjMwNGIyMzM2ZWM2YTczNDA2ZTg5Y2QzZDIxNDNmOTMwNzZhNGNhZTZiZDg1MmU5Nzk0M2NjMzU1YTNkMzYxNDE0MWE1MDI4Yzg4NzBkNmMzYzY3YTY0YjY1NWFhODQxZjA5MTlmYTY1MTVkNDNlZDRhMjZjZTZhODliOTVi; PANPSC=5428563163310095683%3ADJI9ZdfpjgIIg%2FOS0ITt1us60cmUHWkV7bWZIrMKPZyeOrdDpgYagUci2O0YbEjp16SVzr7HdhlX1xOj6A1QcN3Td7LOInJoLtM8%2F9MQPekcejzkeg3hCpwI2lYmdZVOPnTBIG8lTPRVGMKi8gMzL5C9qgHiau%2Fla7VX5fYmxGfiLaLUl0KD5Fk7OsD2Sfvkm5iqNt9Cd%2BsBDChpkEtqiw%3D%3D; Hm_lpvt_d5bdc9eee733100f7b952fc44f7e53e4=1728398889; BAIDUID=E27BA7519BBF3D74C6B6B975214BF525:FG=1; BAIDUID_BFESS=E27BA7519BBF3D74C6B6B975214BF525:FG=1; PANPSC=3951787000303523877%3APBu5R64BDn2C0%2FvqfTAOWVcS2d9ns3O5fCX%2Fmi0NU5Ar1DUGfpqaPgjHRUw%2FZR6kz81ttRoL0tCAzpMjKfHvSs13uoxWjWPiY94v6bOg3aptcQe%2BbgwEaTXkEObzs8aRW8pfgMw2m%2FrhzGIjznB8Pd4Xpx6rjYdD0jtnBLnyK9d7t%2B9ObL%2BIzW3YtMdvXl6norVRx%2Fa05s%2BR2hdKZmRHyATwmM1z8l0ikrFWWqsgPEw%3D',

    }

    response = requests.request("GET", url, headers=headers, data=payload)

    json_data = json.loads(response.text)
    # print(json_data)
    if json_data['res']['subtitle_status']['current_status'] == 200 or json_data['res']['subtitle_status']['current_status'] == 300:
        print("apply成功！！")
        # checkstatus(fs_id)
        geturl(file_path,file_name,save_path,folder_name)


def geturl(path,file_name,save_path,folder_name):

    encoded_path = custom_url_encode(path)


    url = "https://pan.baidu.com/api/streaming?app_id=250528&clienttype=0&channel=chunlei&web=1&isplayer=1&check_blue=1&bdstoken=063abbb0484a65782315d3ef2bceb1ab&dp-logid=48399400489844600002&logId=MDRGNDIxNzY2OTJGODM2NDgwRDRDMzhCMkI1Q0JBREU6Rkc9MQ%3D%3D&path="+encoded_path+"&vip=2&jsToken=25D80DB3925AD70E41EA18F211971C678EC7FA37CF37AE6EF50CCA4D51A28873D543DEEA97BEA96A89C93BA9EED87C0A&type=M3U8_SUBTITLE_SRT&trans=&clienttype=0&app_id=250528&web=1&channel=chunlei&dp-logid=48399400489844600001&logid=MDRGNDIxNzY2OTJGODM2NDgwRDRDMzhCMkI1Q0JBREU6Rkc9MQ%3D%3D"

    payload = {}
    headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Connection': 'keep-alive',
        'Cookie': 'csrfToken=5M01VlShedVdPtQCMvKz97xd; BAIDUID=04F42176692F836480D4C38B2B5CBADE:FG=1; BAIDUID_BFESS=04F42176692F836480D4C38B2B5CBADE:FG=1; newlogin=1; ppfuid=FOCoIC3q5fKa8fgJnwzbE67EJ49BGJeplOzf+4l4EOvDuu2RXBRv6R3A1AZMa49I27C0gDDLrJyxcIIeAeEhD8JYsoLTpBiaCXhLqvzbzmvy3SeAW17tKgNq/Xx+RgOdb8TWCFe62MVrDTY6lMf2GrfqL8c87KLF2qFER3obJGlgR5ugvPeCMvXkTGuVqi9VGEimjy3MrXEpSuItnI4KD/Ga8DcW2V0+9FvwpgBPLhwcG4LQZscCXnsZMrwtZfdxdo1bSe+HrPqGx0UlA4PdtxJsVwXkGdF24AsEQ3K5XBbh9EHAWDOg2T1ejpq0s2eFy9ar/j566XqWDobGoNNfmfpaEhZpob9le2b5QIEdiQez0E9SVndeXkd9EampG0PcXhLZ126CPFCIEuj/nWa+RCvURLVm4bpFOvBv8e58/dDOXSxFWocn8LvXoXRLp3fo5/fbkvdNVYtfeSgcfqcJz7tVNIB9KqyLqpAKG/6PN5nHZFO3SaB4GS7zlBrG2cLm8lTRl19JYcYcqvy3P/50mxpWDwUUC4pvKOF9e+pwNq7l6HzKEZyCMUDd+W6AiaksYiu+4AAz72OnMQfgAyNUbW3IyzL5c+UBht87WUigOY9alcIuR+n1gwn+Dmf3unATYGtv0zKmAog3Ny9wFYiQ/iTCRf3pI4Je1JeNfTzn6XDJZ8Wnjrf/q6TO2bHj5OH24qMgC25gHAxbb/tmQCApEKktJ7CISS0STF94GtUDhRi+72Y/TlJorI8GddU1XzO2O5htkQ9eW+/TVvYXwm0Xd4FIasM3e4G55WFWk5LZRFJNetS6mrAjm2GHsp1aRoBwYzuPaitSx6iW9pOhUZpcjM0Zi+3QrJ+6wvOYvuUOl+A3czNho4/J7j4tBR5DjQtGctmwW/4QqWoxJcNJq8kQzCzwv/fcUl9euhuED/o6m2iVpX0cU4NHwEy/Bqr1kOP1AxyNZHhQVZ2Gp0uL7HNFb+K+jseqgkgNhlYW3G8vU2dGT/8PDdrVN+aMZbHqtS1oD7ul7bRoEgw96s3k/oqBkZVYaMKnX0dWh5E7VnhqRSIp26nF1P0+H9oSyCPQ94PPS//7ugV0/jdYfz/I1urf18mpADR7ExSsg7XRAP5KtKewDFlxCPRBUDxiSr9CI6av6YpcYTnE0hbwjD92IjSd0RHf+nCu+VOrmHAISaUGzAJ/DJesRcpZiTyOfvO7GAwL1dzSAkzWXcpm+ZsJX3HKbA9mEBrXtMGp9ojg0Q3uD1I=; BDUSS=TRyZVBQSHpuZXhJanJkc01vVX4tazNNdGFDYUdNdHdhSDN4UVY1VzJNSjkwaXhuSVFBQUFBJCQAAAAAAAAAAAEAAAAe2xpYdGFuanh0YW43NTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH1FBWd9RQVnW; BDUSS_BFESS=TRyZVBQSHpuZXhJanJkc01vVX4tazNNdGFDYUdNdHdhSDN4UVY1VzJNSjkwaXhuSVFBQUFBJCQAAAAAAAAAAAEAAAAe2xpYdGFuanh0YW43NTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH1FBWd9RQVnW; STOKEN=202db0d3239284d5a1b7ffe814dcaba677d653fbb57620b7908e148a1abfa631; Hm_lvt_d5bdc9eee733100f7b952fc44f7e53e4=1728398723; ndut_fmt=5AB89AA27E6A5680072BB12C6BF8678CCB5EA002EEC474DC65B59553A8C96095; ab_sr=1.0.1_YzVjOTlmOTAzMTY2ZGI5OGQ5NDJiYzFjYzk0Yjk1YzhiY2NlYjBkYTY4OGYxYTA1MDEyMjQwOTQ1NTUwODljNzVlYjMwNGIyMzM2ZWM2YTczNDA2ZTg5Y2QzZDIxNDNmOTMwNzZhNGNhZTZiZDg1MmU5Nzk0M2NjMzU1YTNkMzYxNDE0MWE1MDI4Yzg4NzBkNmMzYzY3YTY0YjY1NWFhODQxZjA5MTlmYTY1MTVkNDNlZDRhMjZjZTZhODliOTVi; PANPSC=5428563163310095683%3ADJI9ZdfpjgIIg%2FOS0ITt1us60cmUHWkV7bWZIrMKPZyeOrdDpgYagUci2O0YbEjp16SVzr7HdhlX1xOj6A1QcN3Td7LOInJoLtM8%2F9MQPekcejzkeg3hCpwI2lYmdZVOPnTBIG8lTPRVGMKi8gMzL5C9qgHiau%2Fla7VX5fYmxGfiLaLUl0KD5Fk7OsD2Sfvkm5iqNt9Cd%2BsBDChpkEtqiw%3D%3D; Hm_lpvt_d5bdc9eee733100f7b952fc44f7e53e4=1728398889; BAIDUID=E27BA7519BBF3D74C6B6B975214BF525:FG=1; BAIDUID_BFESS=E27BA7519BBF3D74C6B6B975214BF525:FG=1; PANPSC=4837836956742010883%3APBu5R64BDn1MfGx%2FULpkHlcS2d9ns3O5fCX%2Fmi0NU5Ar1DUGfpqaPgjHRUw%2FZR6kz81ttRoL0tCAzpMjKfHvSs13uoxWjWPiY94v6bOg3aptcQe%2BbgwEaTXkEObzs8aRW8pfgMw2m%2FrhzGIjznB8Pd4Xpx6rjYdD0jtnBLnyK9d7t%2B9ObL%2BIzW3YtMdvXl6norVRx%2Fa05s%2BR2hdKZmRHyATwmM1z8l0ikrFWWqsgPEw%3D',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"'
    }

    response = requests.request("GET", url, headers=headers, data=payload)
    try:
        jump_url = response.text.split('\n')[3]
    except:
        return
    print(jump_url)
    get_text(jump_url,file_name,save_path,folder_name)

def get_text(jump_url,file_name,save_path,folder_name):

    payload = {}
    headers = {}

    response = requests.request("GET", jump_url, headers=headers, data=payload)

    if folder_name is None:
        output_file_path = os.path.join(save_path, f"{file_name}.srt")
    # print(response.text)
    else:
        # 否则，创建指定的文件夹，并在其中创建文件
        output_folder_path = os.path.join(save_path, folder_name)
        os.makedirs(output_folder_path, exist_ok=True)
        output_file_path = os.path.join(output_folder_path, f"{file_name}.srt")

    with open(output_file_path, 'a', encoding='utf-8') as f:
        f.write(response.text)


def get_subtitles(dir,save_path,folder_name):
    print("检测到开始输出文件夹  " + dir + "  的字幕！！！")
    # dir = '/JS逆向副业大王班1-2期/Python爬虫JS逆向副业大王班：苑老师直播课1期/day07-前端'
    getList(dir,save_path,folder_name)

def get_subtitle_single_file(dir,file_name,save_path):
    print("检测到开始输出单文件  " + dir + "  的字幕！！！")
    # dir = '/JS逆向副业大王班1-2期/Python爬虫JS逆向副业大王班：苑老师直播课1期/day07-前端'
    geturl(dir,file_name, save_path,folder_name = None)



# single_file_path = '/JS逆向副业大王班1-2期/Python爬虫JS逆向副业大王班：苑老师直播课1期/day13-requests模块/05 cookie的玩法_ev.mp4'
# file_name = '05 cookie的玩法_ev.mp4'
# geturl(single_file_path,file_name)

