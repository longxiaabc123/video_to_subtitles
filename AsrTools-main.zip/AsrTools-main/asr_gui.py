import json
import logging
import os
import platform
import re
import subprocess
import webbrowser
from typing import Union
from PyQt5.QtCore import Qt, QRunnable, QThreadPool, QObject, pyqtSignal as Signal, pyqtSlot as Slot, QSize, QThread, \
    pyqtSignal
from PyQt5.QtGui import QCursor, QColor, QFont
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QFileDialog,
                             QTableWidgetItem, QHeaderView, QSizePolicy, QListWidgetItem)
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QListWidget, QPushButton, QLabel
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QHeaderView, QHBoxLayout, QWidget
from PyQt5.QtCore import Qt
from aiohttp.web_response import json_response
from qfluentwidgets import (ComboBox, PushButton, LineEdit, TableWidget, FluentIcon as FIF,
                            Action, RoundMenu, InfoBar, InfoBarPosition,
                            FluentWindow, BodyLabel, MessageBox, NavigationItemPosition, FluentIconBase,
                            NavigationTreeWidget)
from PyQt5.QtWidgets import QTabWidget
from bk_asr.BcutASR import BcutASR
from bk_asr.JianYingASR import JianYingASR
from bk_asr.KuaiShouASR import KuaiShouASR
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton,
    QLineEdit, QTableWidget, QTableWidgetItem, QMessageBox
)
from bd_asr.crawl_baidu_asr import get_subtitles,get_subtitle_single_file  # 调整文件路径
from bili_asr.bili_crawl import search_bilibili  # 导入函数
from bili_asr.bili_parse import parse_video_function  # Adjust the name to your actual function name
from bili_asr.crawl_bili_asr import getjumpurl
import sys
import requests
from bs4 import BeautifulSoup
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QListWidget, QMessageBox
from PyQt5.QtGui import QIcon




# 设置日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


class WorkerSignals(QObject):
    finished = Signal(str, str)
    errno = Signal(str, str)


class ASRWorker(QRunnable):
    """ASR处理工作线程"""
    def __init__(self, file_path, asr_engine):
        super().__init__()
        self.file_path = file_path
        self.asr_engine = asr_engine
        self.signals = WorkerSignals()

    @Slot()
    def run(self):
        try:
            use_cache = True
            # 根据选择的 ASR 引擎实例化相应的类
            if self.asr_engine == '必剪字幕识别':
                asr = BcutASR(self.file_path, use_cache=use_cache)
            elif self.asr_engine == '剪映字幕识别':
                asr = JianYingASR(self.file_path, use_cache=use_cache)
            elif self.asr_engine == '快手字幕识别':
                asr = KuaiShouASR(self.file_path, use_cache=use_cache)
            else:
                raise ValueError(f"未知的 ASR 引擎: {self.asr_engine}")

            logging.info(f"开始处理文件: {self.file_path} 使用引擎: {self.asr_engine}")
            result = asr.run()
            result_text = result.to_srt()
            logging.info(f"完成处理文件: {self.file_path} 使用引擎: {self.asr_engine}")
            save_path = self.file_path.rsplit(".", 1)[0] + ".srt"
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(result_text)
            self.signals.finished.emit(self.file_path, result_text)
        except Exception as e:
            logging.error(f"处理文件 {self.file_path} 时出错: {str(e)}")
            self.signals.errno.emit(self.file_path, f"处理时出错: {str(e)}")



class ASRWidget(QWidget):
    """ASR处理界面"""

    def __init__(self):
        super().__init__()
        self.init_ui()
        self.max_threads = 3  # 设置最大线程数
        self.thread_pool = QThreadPool()
        self.thread_pool.setMaxThreadCount(self.max_threads)
        self.processing_queue = []
        self.workers = {}  # 维护文件路径到worker的映射


    def init_ui(self):
        layout = QVBoxLayout(self)

        # ASR引擎选择下拉框
        self.combo_box = ComboBox(self)
        self.combo_box.addItems(['必剪字幕识别', '剪映字幕识别', '快手字幕识别'])
        layout.addWidget(self.combo_box)

        # 文件选择区域
        file_layout = QHBoxLayout()
        self.file_input = LineEdit(self)
        self.file_input.setPlaceholderText("拖拽文件或文件夹到这里")
        self.file_input.setReadOnly(True)
        self.file_button = PushButton("选择文件", self)
        self.file_button.clicked.connect(self.select_file)
        file_layout.addWidget(self.file_input)
        file_layout.addWidget(self.file_button)
        layout.addLayout(file_layout)

        # 文件列表表格
        self.table = TableWidget(self)
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(['文件名', '状态'])
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        layout.addWidget(self.table)

        # 设置表格列的拉伸模式
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.Fixed)
        self.table.setColumnWidth(1, 100)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # 处理按钮
        self.process_button = PushButton("开始处理", self)
        self.process_button.clicked.connect(self.process_files)
        self.process_button.setEnabled(False)  # 初始禁用
        layout.addWidget(self.process_button)

        self.setAcceptDrops(True)

    def select_file(self):
        """选择文件对话框"""
        files, _ = QFileDialog.getOpenFileNames(self, "选择音频或视频文件", "",
                                                "Media Files (*.mp3 *.wav *.ogg *.mp4 *.avi *.mov *.ts)")
        for file in files:
            self.add_file_to_table(file)
        self.update_start_button_state()

    def add_file_to_table(self, file_path):
        """将文件添加到表格中"""
        if self.find_row_by_file_path(file_path) != -1:
            InfoBar.warning(
                title='文件已存在',
                content=f"文件 {os.path.basename(file_path)} 已经添加到列表中。",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=2000,
                parent=self
            )
            return

        row_count = self.table.rowCount()
        self.table.insertRow(row_count)
        item_filename = self.create_non_editable_item(os.path.basename(file_path))
        item_status = self.create_non_editable_item("未处理")
        item_status.setForeground(QColor("gray"))
        self.table.setItem(row_count, 0, item_filename)
        self.table.setItem(row_count, 1, item_status)
        item_filename.setData(Qt.UserRole, file_path)

    def create_non_editable_item(self, text):
        """创建不可编辑的表格项"""
        item = QTableWidgetItem(text)
        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        return item

    def show_context_menu(self, pos):
        """显示右键菜单"""
        current_row = self.table.rowAt(pos.y())
        if current_row < 0:
            return

        self.table.selectRow(current_row)

        menu = RoundMenu(self)
        reprocess_action = Action(FIF.SYNC, "重新处理")
        delete_action = Action(FIF.DELETE, "删除任务")
        open_dir_action = Action(FIF.FOLDER, "打开文件目录")
        menu.addActions([reprocess_action, delete_action, open_dir_action])

        delete_action.triggered.connect(self.delete_selected_row)
        open_dir_action.triggered.connect(self.open_file_directory)
        reprocess_action.triggered.connect(self.reprocess_selected_file)

        menu.exec(QCursor.pos())

    def delete_selected_row(self):
        """删除选中的行"""
        current_row = self.table.currentRow()
        if current_row >= 0:
            file_path = self.table.item(current_row, 0).data(Qt.UserRole)
            if file_path in self.workers:
                worker = self.workers[file_path]
                worker.signals.finished.disconnect(self.update_table)
                worker.signals.errno.disconnect(self.handle_error)
                # QThreadPool 不支持直接终止线程，通常需要设计任务可中断
                # 这里仅移除引用
                self.workers.pop(file_path, None)
            self.table.removeRow(current_row)
            self.update_start_button_state()

    def open_file_directory(self):
        """打开文件所在目录"""
        current_row = self.table.currentRow()
        if current_row >= 0:
            current_item = self.table.item(current_row, 0)
            if current_item:
                file_path = current_item.data(Qt.UserRole)
                directory = os.path.dirname(file_path)
                try:
                    if platform.system() == "Windows":
                        os.startfile(directory)
                    elif platform.system() == "Darwin":
                        subprocess.Popen(["open", directory])
                    else:
                        subprocess.Popen(["xdg-open", directory])
                except Exception as e:
                    InfoBar.error(
                        title='无法打开目录',
                        content=str(e),
                        orient=Qt.Horizontal,
                        isClosable=True,
                        position=InfoBarPosition.TOP,
                        duration=3000,
                        parent=self
                    )

    def reprocess_selected_file(self):
        """重新处理选中的文件"""
        current_row = self.table.currentRow()
        if current_row >= 0:
            file_path = self.table.item(current_row, 0).data(Qt.UserRole)
            status = self.table.item(current_row, 1).text()
            if status == "处理中":
                InfoBar.warning(
                    title='当前文件正在处理中',
                    content="请等待当前文件处理完成后再重新处理。",
                    orient=Qt.Horizontal,
                    isClosable=True,
                    position=InfoBarPosition.TOP,
                    duration=3000,
                    parent=self
                )
                return
            self.add_to_queue(file_path)

    def add_to_queue(self, file_path):
        """将文件添加到处理队列并更新状态"""
        self.processing_queue.append(file_path)
        self.process_next_in_queue()

    def process_files(self):
        """处理所有未处理的文件"""
        for row in range(self.table.rowCount()):
            if self.table.item(row, 1).text() == "未处理":
                file_path = self.table.item(row, 0).data(Qt.UserRole)
                self.processing_queue.append(file_path)
        self.process_next_in_queue()

    def process_next_in_queue(self):
        """处理队列中的下一个文件"""
        while self.thread_pool.activeThreadCount() < self.max_threads and self.processing_queue:
            file_path = self.processing_queue.pop(0)
            if file_path not in self.workers:
                self.process_file(file_path)

    def process_file(self, file_path):
        """处理单个文件"""
        selected_engine = self.combo_box.currentText()
        worker = ASRWorker(file_path, selected_engine)
        worker.signals.finished.connect(self.update_table)
        worker.signals.errno.connect(self.handle_error)
        self.thread_pool.start(worker)
        self.workers[file_path] = worker

        row = self.find_row_by_file_path(file_path)
        if row != -1:
            status_item = self.create_non_editable_item("处理中")
            status_item.setForeground(QColor("orange"))
            self.table.setItem(row, 1, status_item)
            self.update_start_button_state()

    def update_table(self, file_path, result):
        """更新表格中文件的处理状态"""
        row = self.find_row_by_file_path(file_path)
        if row != -1:
            item_status = self.create_non_editable_item("已处理")
            item_status.setForeground(QColor("green"))
            self.table.setItem(row, 1, item_status)

            InfoBar.success(
                title='处理完成',
                content=f"文件 {self.table.item(row, 0).text()} 已处理完成",
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=1500,
                parent=self
            )

        self.workers.pop(file_path, None)
        self.process_next_in_queue()
        self.update_start_button_state()

    def handle_error(self, file_path, error_message):
        """处理错误信息"""
        row = self.find_row_by_file_path(file_path)
        if row != -1:
            item_status = self.create_non_editable_item("错误")
            item_status.setForeground(QColor("red"))
            self.table.setItem(row, 1, item_status)

            InfoBar.error(
                title='处理出错',
                content=error_message,
                orient=Qt.Horizontal,
                isClosable=True,
                position=InfoBarPosition.TOP,
                duration=3000,
                parent=self
            )

        self.workers.pop(file_path, None)
        self.process_next_in_queue()
        self.update_start_button_state()

    def find_row_by_file_path(self, file_path):
        """根据文件路径查找表格中的行号"""
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item.data(Qt.UserRole) == file_path:
                return row
        return -1

    def update_start_button_state(self):
        """根据文件列表更新开始处理按钮的状态"""
        has_unprocessed = any(
            self.table.item(row, 1).text() == "未处理"
            for row in range(self.table.rowCount())
        )
        self.process_button.setEnabled(has_unprocessed)

    def dragEnterEvent(self, event):
        """拖拽进入事件"""
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        """拖拽释放事件"""
        supported_formats = ('.mp3', '.wav', '.ogg', '.mp4', '.avi', '.mov', '.ts')
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        for file in files:
            if os.path.isdir(file):
                for root, dirs, files_in_dir in os.walk(file):
                    for f in files_in_dir:
                        if f.lower().endswith(supported_formats):
                            self.add_file_to_table(os.path.join(root, f))
            elif file.lower().endswith(supported_formats):
                self.add_file_to_table(file)
        self.update_start_button_state()


class InfoWidget(QWidget):
    """个人信息界面"""

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        # GitHub URL 和仓库描述
        GITHUB_URL = "https://github.com/WEIFENG2333/AsrTools"
        REPO_DESCRIPTION = """
    💸 基于GitHub项目二次开发，调用大厂接口：支持包括剪映、快手、必剪多家大厂接口。
    🚀 无需复杂配置：无需 GPU 和繁琐的本地配置，小白也能轻松使用。
    🖥️ 高颜值界面：基于 PyQt5 和 qfluentwidgets，界面美观且用户友好。
    ⚡ 效率超人：多线程并发 + 批量处理，文字转换快如闪电。
    📄 多格式支持：支持生成 .srt 和 .txt 字幕文件，满足不同需求。
    🔍 剪映接口：逆向还原剪映软件的字幕识别接口，与官方体验一致，稳定可靠。
        """

        main_layout = QVBoxLayout(self)
        main_layout.setAlignment(Qt.AlignTop)
        # main_layout.setSpacing(50)

        # 标题
        title_label = BodyLabel("  ASRTools", self)
        title_label.setFont(QFont("Segoe UI", 30, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)

        # 仓库描述区域
        desc_label = BodyLabel(REPO_DESCRIPTION, self)
        desc_label.setFont(QFont("Segoe UI", 12))
        main_layout.addWidget(desc_label)

        github_button = PushButton("GitHub 仓库", self)
        github_button.setIcon(FIF.GITHUB)
        github_button.setIconSize(QSize(20, 20))
        github_button.setMinimumHeight(42)
        github_button.clicked.connect(lambda _: webbrowser.open(GITHUB_URL))
        main_layout.addWidget(github_button)


class BaiduNetDisk(QWidget):
    """百度网盘接口"""

    def __init__(self):
        super().__init__()
        self.current_dir = '/'  # 初始化为根目录
        self.session = requests.Session()  # 初始化请求会话
        self.path_stack = []  # 用于存储目录路径
        self.setObjectName("baiduNetDiskWidget")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # 状态标签
        self.status_label = QLabel("未登录", self)
        layout.addWidget(self.status_label)

        # Cookie 输入框
        self.cookie_input = QLineEdit(self)
        self.cookie_input.setPlaceholderText("输入百度网盘 Cookie")
        layout.addWidget(self.cookie_input)

        # 登录按钮
        self.login_button = QPushButton("登录百度网盘", self)
        self.login_button.clicked.connect(self.login_with_cookie)
        layout.addWidget(self.login_button)

        # 文件列表表格
        self.file_list_table = QTableWidget(self)
        self.file_list_table.setColumnCount(3)  # 增加一列用于按钮
        self.file_list_table.setHorizontalHeaderLabels(['文件名', '大小', '操作'])
        self.file_list_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.file_list_table.cellDoubleClicked.connect(self.on_item_double_clicked)
        layout.addWidget(self.file_list_table)

        # 创建一个水平布局用于底部按钮
        bottom_layout = QHBoxLayout()

        # 返回上一级按钮
        self.back_button = QPushButton("返回上一级", self)
        self.back_button.clicked.connect(self.go_back)
        bottom_layout.addWidget(self.back_button)

        # 进入下一级目录按钮
        self.enter_button = QPushButton("进入下一级目录", self)
        self.enter_button.clicked.connect(self.enter_directory)
        bottom_layout.addWidget(self.enter_button)

        layout.addLayout(bottom_layout)  # 将底部按钮布局添加到主要布局

    def login_with_cookie(self):
        """使用 Cookie 登录"""
        cookie = self.cookie_input.text()
        if not cookie:
            QMessageBox.warning(self, "警告", "请输入 Cookie")
            return

        # 设置 Cookie
        self.session.cookies.set('Cookie', cookie)

        # 加载根目录文件列表
        self.load_file_list()



    def load_file_list(self):
        """加载当前目录的文件列表"""
        url = f"https://pan.baidu.com/rest/2.0/xpan/file?method=list&dir={self.current_dir}"
        response = self.session.get(url)

        if response.ok:
            result = response.json()

            if result.get("errno") == 0 and 'list' in result:
                file_list = result['list']

                # 分别存放文件夹和文件
                directories = [item for item in file_list if item['isdir']]
                files = [item for item in file_list if not item['isdir']]

                # 分别根据最近修改时间排序
                directories.sort(key=lambda x: x['server_mtime'], reverse=True)
                files.sort(key=lambda x: x['server_mtime'], reverse=True)

                self.file_list_table.setRowCount(0)  # 清空表格

                # 添加文件夹到表格
                for item in directories:
                    file_name = item['server_filename']
                    self.add_file_to_list(file_name, {}, True)  # 接受一个空的字典作为文件信息

                # 添加文件到表格
                for item in files:
                    file_name = item['server_filename']
                    file_size = item.get('size', 0)  # 获取文件大小
                    self.add_file_to_list(file_name, {'size': file_size}, False)  # 传递文件的大小

                self.status_label.setText("登录成功")
            else:
                QMessageBox.warning(self, "错误", "无法获取文件列表")
        else:
            QMessageBox.warning(self, "错误", f"请求失败: {response.status_code}")

    def format_file_size(self, size_in_bytes):
        """根据字节大小返回合适的文件大小格式"""
        if size_in_bytes is None or size_in_bytes < 0:
            return "未知大小"

        units = ['Bytes', 'KB', 'MB', 'GB', 'TB']
        index = 0
        size = float(size_in_bytes)

        while size >= 1024 and index < len(units) - 1:
            size /= 1024.0
            index += 1

        return f"{size:.2f} {units[index]}"  # 保留两位小数并加上单位



    # file_link = f"https://pan.baidu.com/share/link?shareid={item['fs_id']}&uk={item['owner_id']}"
    def add_file_to_list(self, file_name, file_info, is_dir):
        """将文件或目录添加到表格"""
        row_count = self.file_list_table.rowCount()
        self.file_list_table.insertRow(row_count)

        filename_item = QTableWidgetItem(file_name)

        # 如果是文件夹，我们只填充“文件夹”；如果是文件，则填充文件大小
        if is_dir:
            link_item = QTableWidgetItem("文件夹")
        else:
            file_size = file_info.get('size', 0)  # 获取文件大小（字节）
            formatted_size = self.format_file_size(file_size)  # 格式化文件大小
            link_item = QTableWidgetItem(formatted_size)

        operation_button = QPushButton("输出字幕")  # 创建输出字幕按钮

        self.file_list_table.setItem(row_count, 0, filename_item)
        self.file_list_table.setItem(row_count, 1, link_item)
        self.file_list_table.setCellWidget(row_count, 2, operation_button)  # 将按钮添加到指定单元格

        # 连接按钮的点击事件
        operation_button.clicked.connect(lambda: self.output_subtitles(file_name, is_dir))

        # 设置文件夹的行背景色为浅蓝色
        if is_dir:
            self.file_list_table.item(row_count, 0).setBackground(QColor(173, 216, 230))  # 浅蓝色
            self.file_list_table.item(row_count, 1).setBackground(QColor(173, 216, 230))  # 浅蓝色

    def output_subtitles(self, file_name, is_dir):
        """根据是文件还是文件夹决定处理逻辑"""
        save_path = QFileDialog.getExistingDirectory(self, "选择保存路径")
        if not save_path:
            return

        if is_dir:
            # 处理文件夹输出
            self.output_subtitles_for_folder(file_name, save_path)
        else:
            # 处理单文件输出
            # 获取完整的文件路径
            single_file_path = os.path.join(self.current_dir, file_name)
            self.output_subtitle_for_file(single_file_path, save_path)


    def on_item_double_clicked(self, row, column):
        """处理双击进入目录"""
        item = self.file_list_table.item(row, 0)
        file_name = item.text()

        # 检查该项是否为文件夹
        if "文件夹" in self.file_list_table.item(row, 1).text():
            self.path_stack.append(self.current_dir)  # 保存当前路径
            self.current_dir += file_name + "/"  # 更新当前目录
            self.load_file_list()  # 重新加载文件列表

    def go_back(self):
        """返回上一级目录"""
        if self.path_stack:
            self.current_dir = self.path_stack.pop()  # 恢复上一级目录
            self.load_file_list()  # 重新加载文件列表
        else:
            QMessageBox.information(self, "提示", "已经是根目录，无法返回上一级目录。")

    def enter_directory(self):
        """进入下一级目录"""
        selected_row = self.file_list_table.currentRow()  # 获取当前选中的行
        if selected_row >= 0:  # 检查是否选中
            item = self.file_list_table.item(selected_row, 0)
            file_name = item.text()

            # 检查该项是否为文件夹
            if "文件夹" in self.file_list_table.item(selected_row, 1).text():
                self.path_stack.append(self.current_dir)  # 保存当前路径
                self.current_dir += file_name + "/"  # 更新当前目录
                self.load_file_list()  # 重新加载文件列表
            else:
                QMessageBox.warning(self, "提示", "请选择一个文件夹以进入。")
        else:
            QMessageBox.warning(self, "提示", "请先选择一个文件夹。")



    def output_subtitles_for_folder(self, folder_name, save_path):
        """输出该文件夹的字幕"""

        # 获取完整的文件夹路径
        folder_path = os.path.join(self.current_dir, folder_name)

        # 调用 get_subtitles 函数，传入文件夹路径
        try:
            get_subtitles(folder_path,save_path,folder_name)  # 替换为您获取字幕的函数
            QMessageBox.information(self, "成功", f"{folder_name} 的字幕生成成功！")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"在生成字幕时发生错误: {str(e)}")

    def output_subtitle_for_file(self, single_file_path, save_path):
        """处理单文件生成字幕"""

        # 提示用户正在生成字幕
        QMessageBox.information(self, "输出字幕", f"正在生成 {single_file_path} 的字幕，保存路径为: {save_path}。")

        # 提取文件名
        file_name = os.path.basename(single_file_path)

        # 调用 get_subtitle_single_file 函数，传入百度网盘路径和保存路径
        try:
            get_subtitle_single_file(single_file_path, file_name, save_path)
            QMessageBox.information(self, "成功", f"{file_name} 的字幕生成成功！")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"在生成字幕时发生错误: {str(e)}")


class ParseVideoDialog(QDialog):
    def __init__(self, videos, aid, parent=None):
        super().__init__(parent)
        self.setWindowTitle("视频解析结果")
        self.setGeometry(100, 100, 600, 400)

        main_layout = QVBoxLayout(self)

        parse_table = QTableWidget(self)
        parse_table.setColumnCount(3)
        parse_table.setHorizontalHeaderLabels(["标题", "时长", "操作"])
        parse_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        for i, video in enumerate(videos):
            parse_table.insertRow(i)
            parse_table.setItem(i, 0, QTableWidgetItem(video['title']))
            parse_table.setItem(i, 1, QTableWidgetItem(str(video['duration'])))

            parse_button = QPushButton("输出单文件字幕", self)
            parse_button.clicked.connect(lambda checked, video_id=video['video_id'],video_title = video['title']: self.parse_single_file(video_title,video_id, aid))  # Pass aid to the method
            parse_table.setCellWidget(i, 2, parse_button)

        main_layout.addWidget(parse_table)
        self.setLayout(main_layout)

    def parse_single_file(self,video_title, video_id, aid):
        """根据是文件还是文件夹决定处理逻辑"""
        save_path = QFileDialog.getExistingDirectory(self, "选择保存路径")
        if not save_path:
            return
        # Implement single file parsing logic
        print(f"解析单文件,视频cid为: {video_id}, AID为: {aid}")
        getjumpurl(aid,video_id,save_path,video_title,list_title=None)

class BiliBili(QWidget):
    """哔哩哔哩界面"""

    COOKIE_FILE = 'cookie.txt'  # Cookie 文件名

    def __init__(self):
        super().__init__()
        self.init_ui()
        self.load_cookie()

    def init_ui(self):
        layout = QVBoxLayout()

        # 添加 Cookie 输入框
        self.cookie_label = QLabel("请输入 B站 Cookie:", self)
        layout.addWidget(self.cookie_label)

        self.cookie_input = QLineEdit(self)
        layout.addWidget(self.cookie_input)

        # 添加保存 Cookie 按钮
        self.save_cookie_button = QPushButton("保存 Cookie", self)
        self.save_cookie_button.clicked.connect(self.save_cookie)
        layout.addWidget(self.save_cookie_button)

        # 添加搜索框
        self.search_box = QLineEdit(self)
        self.search_box.setPlaceholderText("输入关键字搜索视频")
        layout.addWidget(self.search_box)

        # 添加搜索按钮
        self.search_button = QPushButton("搜索", self)
        self.search_button.clicked.connect(self.search_videos)
        layout.addWidget(self.search_button)

        # 更新为表格控件
        self.video_table = QTableWidget(self)
        self.video_table.setColumnCount(5)  # 四列
        self.video_table.setHorizontalHeaderLabels(["视频信息", "UP主", "视频时长", "操作","批量操作"])  # 设置表头
        self.video_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)  # 自适应宽度

        # 设置表格的最小高度 (根据需要进行调整)
        self.video_table.setMinimumHeight(400)  # 设置最小高度

        layout.addWidget(self.video_table)


        self.setLayout(layout)



    def load_cookie(self):
        if os.path.exists(self.COOKIE_FILE):
            with open(self.COOKIE_FILE, 'r') as f:
                cookie = f.read().strip()
                self.cookie_input.setText(cookie)
        else:
            self.cookie_label.setText("未找到 Cookie，请输入并保存。")

    def save_cookie(self):
        cookie = self.cookie_input.text().strip()
        if cookie:
            with open(self.COOKIE_FILE, 'w') as f:
                f.write(cookie)
            QMessageBox.information(self, "成功", "Cookie 已保存！")
        else:
            QMessageBox.warning(self, "警告", "Cookie 不能为空！")

    def search_videos(self):
        if not self.cookie_input.text().strip():
            QMessageBox.warning(self, "警告", "请先输入 Cookie！")
            return
        keyword = self.search_box.text()
        if keyword:
            self.load_search_results(keyword)

    def load_search_results(self, keyword):
        self.video_table.setRowCount(0)  # 清空之前的结果

        # 调用 bili_crawl.py 中的函数
        result = search_bilibili(keyword)

        if result:  # 检查是否返回了有效的结果
            titles = result.get('titles', [])  # 视频标题
            urls = result.get('urls', [])  # 视频链接
            up_authors = result.get('up_authors', [])  # UP主
            durations = result.get('durations', [])  # 视频时长

            # 逐个将视频信息添加到表格中
            for i in range(len(titles)):
                self.video_table.insertRow(i)

                # 添加视频标题
                self.video_table.setItem(i, 0, QTableWidgetItem(titles[i]))

                # 添加 UP主
                self.video_table.setItem(i, 1, QTableWidgetItem(up_authors[i]))

                # 添加视频时长
                self.video_table.setItem(i, 2, QTableWidgetItem(durations[i]))

                # 添加解析按钮
                parse_button = QPushButton("解析", self)
                parse_button.clicked.connect(lambda checked, url=urls[i]: self.parse_video(url))
                self.video_table.setCellWidget(i, 3, parse_button)  # 四列添加按钮

                # 添加解析按钮
                parse_button2 = QPushButton("输出合集/列表字幕", self)
                parse_button2.clicked.connect(lambda checked, url=urls[i],title=titles[i]: self.parse_list_video(title,url))
                self.video_table.setCellWidget(i, 4, parse_button2)  # 四列添加按钮

        else:
            QMessageBox.warning(self, "警告", "未找到任何视频结果，请重试！")

    def extract_aid_from_url(self, url):
        match = re.search(r'/(av|BV)(\d+)', url)
        return match.group(2) if match else None

    def parse_video(self, url):
        aid = self.extract_aid_from_url(url)
        if aid:
            try:
                videos = parse_video_function(aid)  # 调用解析函数
                if videos:
                    dialog = ParseVideoDialog(videos,aid , self)
                    dialog.exec_()
                else:
                    QMessageBox.warning(self, "错误", "未能解析到视频信息。")
            except Exception as e:
                QMessageBox.warning(self, "错误", f"解析视频失败: {e}")
        else:
            QMessageBox.warning(self, "错误", "未能提取 AID，请检查视频 URL。")


    def parse_list_video(self,list_title,url):
        aid = self.extract_aid_from_url(url)
        if aid:
            try:
                save_path = QFileDialog.getExistingDirectory(self, "选择保存路径")
                if not save_path:
                    return
                videos = parse_video_function(aid)  # 调用解析函数
                print(videos)
                for video in videos:
                    cid = video['video_id']
                    print(f"批量解析文件,合集名称为:{list_title}, 视频标题为: {video['title']} 视频cid为: {cid}, AID为: {aid}")
                    getjumpurl(aid, cid, save_path, video['title'],list_title)


            except Exception as e:
                QMessageBox.warning(self, "错误", f"解析视频失败: {e}")
        else:
            QMessageBox.warning(self, "错误", "未能提取 AID，请检查视频 URL。")








class MainWindow(FluentWindow):
   """主窗口"""

   def __init__(self):
       super().__init__()
       self.setWindowTitle('龙虾先生字幕生成器')

       # 初始化 tab_widget
       self.tab_widget = QTabWidget()
       layout = QVBoxLayout()
       layout.addWidget(self.tab_widget)
       self.setLayout(layout)

       # ASR 处理界面
       self.asr_widget = ASRWidget()
       self.asr_widget.setObjectName("main")
       self.addSubInterface(self.asr_widget, FIF.ALBUM, '本地语音识别')

       # 个人信息界面
       self.info_widget = InfoWidget()
       self.info_widget.setObjectName("info")
       self.addSubInterface(self.info_widget, FIF.GITHUB, 'About')

       # 百度网盘界面
       self.baidu_widget = BaiduNetDisk()
       self.baidu_widget.setObjectName("baiduNetDisk")
       baidu_icon = QIcon("icon/百度网盘.png")
       self.addSubInterface(self.baidu_widget, baidu_icon, '百度网盘')  # 确保提供图标

       # 哔哩哔哩界面
       self.bilibili_widget = BiliBili()
       self.bilibili_widget.setObjectName("bilibili")
       bilibili_icon = QIcon("icon/哔哩哔哩.png")
       self.addSubInterface(self.bilibili_widget, bilibili_icon, '哔哩哔哩')  # 确保提供图标


       self.navigationInterface.setExpandWidth(200)
       self.resize(800, 600)



   def addSubInterface(self, interface: QWidget, icon: Union[FluentIconBase, QIcon, str], text: str,
                       position=NavigationItemPosition.TOP, parent=None, isTransparent=False) -> NavigationTreeWidget:
       # 调用父类的 addSubInterface 方法
       return super().addSubInterface(interface, icon, text, position, parent, isTransparent)

   def show_msg(self, title, content, update_download_url):
        w = MessageBox(title, content, self)
        if w.exec() and update_download_url:
            webbrowser.open(update_download_url)
        if title == "更新":
            sys.exit(0)



def start():
    # enable dpi scale
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps)

    app = QApplication(sys.argv)
    # setTheme(Theme.DARK)  # 如果需要深色主题，取消注释此行
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    start()
