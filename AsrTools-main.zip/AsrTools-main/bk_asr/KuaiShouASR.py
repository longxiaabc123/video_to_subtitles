import requests
from typing import Union, Dict, List  # 添加导入

from .ASRData import ASRDataSeg
from .BaseASR import BaseASR


class KuaiShouASR(BaseASR):
    def __init__(self, audio_path: Union[str, bytes], use_cache: bool = False):  # 更新类型提示
        super().__init__(audio_path, use_cache)

    def _run(self) -> Dict:  # 更新返回类型
        return self._submit()

    def _make_segments(self, resp_data: Dict) -> List[ASRDataSeg]:  # 更新返回类型
        return [ASRDataSeg(u['text'], u['start_time'], u['end_time']) for u in resp_data['data']['text']]

    def _submit(self) -> Dict:  # 更新返回类型
        payload = {
            "typeId": "1"
        }
        files = [('file', ('test.mp3', self.file_binary, 'audio/mpeg'))]
        result = requests.post("https://ai.kuaishou.com/api/effects/subtitle_generate", data=payload, files=files)
        return result.json()


if __name__ == '__main__':
    # Example usage
    audio_file = r"C:\Users\dailinxin\Downloads\26250184053-1-30216.mp3"
    asr = KuaiShouASR(audio_file)
    asr_data = asr.run()
    print(asr_data)