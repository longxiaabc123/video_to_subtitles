import json
import logging
import os
import zlib
import tempfile
import threading
from typing import List  # Import List for type hinting

from moviepy.audio.io.AudioFileClip import AudioFileClip

from .ASRData import ASRDataSeg, ASRData


class BaseASR:
    SUPPORTED_SOUND_FORMAT = ["flac", "m4a", "mp3", "wav","mp4","avi"]
    CACHE_FILE = os.path.join(tempfile.gettempdir(), "bk_asr", "asr_cache.json")
    _lock = threading.Lock()

    def __init__(self, audio_path: [str, bytes], use_cache: bool = False):
        self.audio_path = audio_path
        self.file_binary = None

        self.crc32_hex = None
        self.use_cache = use_cache

        self._set_data()

        self.cache = self._load_cache()

    def _load_cache(self):
        if not self.use_cache:
            return {}
        os.makedirs(os.path.dirname(self.CACHE_FILE), exist_ok=True)
        with self._lock:
            if os.path.exists(self.CACHE_FILE):
                try:
                    with open(self.CACHE_FILE, 'r', encoding='utf-8') as f:
                        cache = json.load(f)
                        if isinstance(cache, dict):
                            return cache
                except (json.JSONDecodeError, IOError):
                    return {}
            return {}

    def _save_cache(self):
        if not self.use_cache:
            return
        with self._lock:
            try:
                with open(self.CACHE_FILE, 'w', encoding='utf-8') as f:
                    json.dump(self.cache, f, ensure_ascii=False, indent=2)
                if os.path.exists(self.CACHE_FILE) and os.path.getsize(self.CACHE_FILE) > 10 * 1024 * 1024:
                    os.remove(self.CACHE_FILE)
            except IOError as e:
                logging.error(f"Failed to save cache: {e}")

    # 不转mp3 直接上传
    def _set_data(self):
        if isinstance(self.audio_path, bytes):
            self.file_binary = self.audio_path
        else:
            ext = self.audio_path.split(".")[-1].lower()
            assert ext in self.SUPPORTED_SOUND_FORMAT, f"Unsupported sound format: {ext}"
            assert os.path.exists(self.audio_path), f"File not found: {self.audio_path}"
            with open(self.audio_path, "rb") as f:
                self.file_binary = f.read()
        crc32_value = zlib.crc32(self.file_binary) & 0xFFFFFFFF
        self.crc32_hex = format(crc32_value, '08x')

    # 本地转mp3 再上传
    # def _set_data(self):
    #     if isinstance(self.audio_path, bytes):
    #         self.file_binary = self.audio_path
    #     else:
    #         ext = self.audio_path.split(".")[-1].lower()
    #         if ext == "mp4" or ext == 'avi':  # Handle mp4 format
    #             self.file_binary = self._extract_audio_from_mp4(self.audio_path)
    #         else:
    #             assert ext in self.SUPPORTED_SOUND_FORMAT, f"Unsupported sound format: {ext}"
    #             assert os.path.exists(self.audio_path), f"File not found: {self.audio_path}"
    #             with open(self.audio_path, "rb") as f:
    #                 self.file_binary = f.read()
    #
    #     crc32_value = zlib.crc32(self.file_binary) & 0xFFFFFFFF
    #     self.crc32_hex = format(crc32_value, '08x')
    #
    # # mp3临时文件
    # def _extract_audio_from_mp4(self, mp4_path: str):
    #     """
    #     Extract audio from an MP4 file and return it as bytes.
    #     """
    #     temp_audio_file = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)  # Create a temporary mp3 file
    #     temp_audio_file.close()  # Close the file immediately to avoid file locking issues
    #     try:
    #         with AudioFileClip(mp4_path) as audio:
    #             audio.write_audiofile(temp_audio_file.name, codec='mp3')  # Convert to mp3
    #         with open(temp_audio_file.name, 'rb') as f:  # Read the binary data
    #             return f.read()
    #     except Exception as e:
    #         logging.error(f"Failed to extract audio from MP4: {e}")
    #         raise
    #     finally:
    #         # Attempt to remove the temporary file
    #         try:
    #             os.remove(temp_audio_file.name)
    #         except Exception as remove_exception:
    #             logging.error(f"Could not delete temporary audio file: {remove_exception}")

    # mp3 永久保存
    # def _extract_audio_from_mp4(self, mp4_path: str):
    #     """
    #     Extract audio from an MP4 file and save it as an MP3 file in the same directory.
    #     """
    #     # Determine the output MP3 file path
    #     base_name = os.path.splitext(mp4_path)[0]  # Get the file name without extension
    #     mp3_file_path = f"{base_name}.mp3"  # Create the MP3 file path
    #
    #     try:
    #         with AudioFileClip(mp4_path) as audio:
    #             audio.write_audiofile(mp3_file_path, codec='mp3')  # Convert and save the mp3
    #         # Return the binary data of the saved mp3 file
    #         with open(mp3_file_path, 'rb') as f:  # Read the binary data
    #             return f.read()
    #     except Exception as e:
    #         logging.error(f"Failed to extract audio from MP4: {e}")
    #         raise

    def _get_key(self):
        return f"{self.__class__.__name__}-{self.crc32_hex}"

    def run(self):
        k = self._get_key()
        if k in self.cache and self.use_cache:
            resp_data = self.cache[k]
        else:
            resp_data = self._run()
            # Cache the result
            self.cache[k] = resp_data
            self._save_cache()
        segments = self._make_segments(resp_data)
        return ASRData(segments)

    def _make_segments(self, resp_data: dict) -> List[ASRDataSeg]:  # Use List here
        raise NotImplementedError("_make_segments method must be implemented in subclass")

    def _run(self) -> dict:
        """ Run the ASR service and return the response data. """
        raise NotImplementedError("_run method must be implemented in subclass")


