import json

import requests

def parse_video_function(aid):
    url = f"https://api.bilibili.com/x/web-interface/wbi/view/detail?aid={aid}&need_view=1&isGaiaAvoided=false&web_location=1315873&w_rid=5fa49443239c8611ce7e91309329b44a&wts=1728787688"

    payload = {}
    headers = {
      'accept': 'application/json, text/plain, */*',
      'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
      'cookie': 'buvid3=41274A75-074F-B7E9-4E36-2A0C817023CD17891infoc; b_nut=1728143617; _uuid=ED7E9CDC-EFC3-10D63-445F-C9B56B6C1019818098infoc; buvid_fp=6f8cafb1fe23e3b3438d87d27ef6a0d3; enable_web_push=DISABLE; buvid4=DD3B0A9C-2D8E-D87F-CBB6-C1153D4F2FE719693-024100515-PxaXIe7uZiMjJrRqm4rA6g%3D%3D; SESSDATA=d812e28c%2C1743695663%2Cb38ed%2Aa1CjDdYN_px8XPQPQTp0Hac99woVXwumnoT3hHo7DO52z9C9JThDCNY95n4omEBUdLLUYSVjdrWFozbmZpX0dqWXFWbGphcnVsREhFZGlYak0tN0dsZDlxNnVOVUFMdG9VNEpnYW5OTldTU1AxRzNiSkRfeDhreldGRGR5SHBPaVF6Z1E5Q0tBdU53IIEC; bili_jct=11d4f2cd0ff6195fc14587465af21d22; DedeUserID=543527307; DedeUserID__ckMd5=4322a398c554b6a3; header_theme_version=CLOSE; bp_t_offset_543527307=984892411073265664; CURRENT_BLACKGAP=0; bsource=search_bing; CURRENT_FNVAL=4048; rpdid=|(umk~uYml)~0J\'u~k)km)muY; sid=59n3ezbf; home_feed_column=4; browser_resolution=711-746; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjkwMjM4MDksImlhdCI6MTcyODc2NDU0OSwicGx0IjotMX0.jr31cTQJcAIkJHbkX9WbpjrAyZHtc6KxQooSkk2scqs; bili_ticket_expires=1729023749; b_lsid=41B10272A_192838F46BE; sid=qi0j2095',
      'origin': 'https://www.bilibili.com',
      'priority': 'u=1, i',
      'referer': 'https://www.bilibili.com/video/av1250517289/?vd_source=b35b80b89f6098d9a96d1126f51d213e',
      'sec-ch-ua': '"Microsoft Edge";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-site',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0'
    }

    response = requests.request("GET", url, headers=headers, data=payload)

    json_data = json.loads(response.text)
    result = []

    pages = json_data['data']['View']['pages']
    if len(pages) > 1:
        # Video List
        print('是视频列表')
        print('列表里面视频数量：' + str(len(pages)))

        for page in pages:
            video_info = {
                'title': page['part'],
                # 'url': f"https://www.bilibili.com/video/av{page['cid']}",  # Construct URL as needed
                'duration': page['duration'],
                'first_frame': page.get('first_frame', ''),  # Use an empty string if 'first_frame' does not exist
                'video_id': page['cid'],
                'type': 'list'
            }
            result.append(video_info)

    elif len(pages) == 1:
        # Single Video or Video Collection
        if 'ugc_season' in json_data['data']['View']:
            print('是视频合集')
            ugc_season = json_data['data']['View']['ugc_season']
            print('合集里面视频数量：' + str(ugc_season['ep_count']))

            # Extract information from the 'ugc_season' structure
            for section in ugc_season['sections']:
                for episode in section['episodes']:
                    episode_info = {
                        'title': episode['title'],
                        # 'url': f"https://www.bilibili.com/video/av{episode['cid']}",  # Construct URL as needed
                        'duration': episode['arc']['duration'],
                        'first_frame': episode['arc']['pic'],  # Use 'arc' picture as the first frame
                        'video_id': episode['cid'],
                        'bvid': episode['bvid'],
                        'season_id': ugc_season['id'],
                        'type': 'collection'
                    }
                    result.append(episode_info)
        else:
            print('是单视频')
            page = pages[0]
            video_info = {
                'title': page['part'],
                # 'url': f"https://www.bilibili.com/video/av{page['cid']}",  # Construct URL as needed
                'duration': page['duration'],
                'first_frame': page.get('first_frame', ''),  # Use an empty string if 'first_frame' does not exist
                'video_id': page['cid'],
                'type': 'single_video'
            }
            result.append(video_info)

    else:
        print("视频错误")

    return result  # Return the list of video information
