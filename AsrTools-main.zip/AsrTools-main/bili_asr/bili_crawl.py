import json

import requests
from bs4 import BeautifulSoup


def search_bilibili(keyword):
    url = f"https://api.bilibili.com/x/web-interface/wbi/search/all/v2?__refresh__=true&_extra=&context=&page=1&page_size=42&order=&pubtime_begin_s=0&pubtime_end_s=0&duration=&from_source=&from_spmid=333.337&platform=pc&highlight=1&single_column=0&keyword={keyword}&qv_id=YKpJ01RRG20lQcbuMWrbSBdt3GlXdote&ad_resource=5646&source_tag=3&web_location=1430654&w_rid=648fc51d46ef73a8ede84366639bf96e"
    payload = {}
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'cookie': 'buvid3=41274A75-074F-B7E9-4E36-2A0C817023CD17891infoc; b_nut=1728143617; _uuid=ED7E9CDC-EFC3-10D63-445F-C9B56B6C1019818098infoc; buvid_fp=6f8cafb1fe23e3b3438d87d27ef6a0d3; enable_web_push=DISABLE; buvid4=DD3B0A9C-2D8E-D87F-CBB6-C1153D4F2FE719693-024100515-PxaXIe7uZiMjJrRqm4rA6g%3D%3D; SESSDATA=d812e28c%2C1743695663%2Cb38ed%2Aa1CjDdYN_px8XPQPQTp0Hac99woVXwumnoT3hHo7DO52z9C9JThDCNY95n4omEBUdLLUYSVjdrWFozbmZpX0dqWXFWbGphcnVsREhFZGlYak0tN0dsZDlxNnVOVUFMdG9VNEpnYW5OTldTU1AxRzNiSkRfeDhreldGRGR5SHBPaVF6Z1E5Q0tBdU53IIEC; bili_jct=11d4f2cd0ff6195fc14587465af21d22; DedeUserID=543527307; DedeUserID__ckMd5=4322a398c554b6a3; header_theme_version=CLOSE; bp_t_offset_543527307=984892411073265664; CURRENT_BLACKGAP=0; bsource=search_bing; CURRENT_FNVAL=4048; rpdid=|(umk~uYml)~0J\'u~k)km)muY; sid=59n3ezbf; b_lsid=F4F52E38_1928242F64E; home_feed_column=4; browser_resolution=711-746; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjkwMjM4MDksImlhdCI6MTcyODc2NDU0OSwicGx0IjotMX0.jr31cTQJcAIkJHbkX9WbpjrAyZHtc6KxQooSkk2scqs; bili_ticket_expires=1729023749; sid=qi0j2095',
        'origin': 'https://search.bilibili.com',
        'priority': 'u=1, i',
        'referer': 'https://search.bilibili.com/all?keyword=%E8%80%81%E9%AB%98%E4%B8%8E%E5%B0%8F%E8%8C%89%E6%9C%80%E6%96%B0&search_source=1',
        'sec-ch-ua': '"Microsoft Edge";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0'
    }

    try:
        response = requests.get(url, headers=headers)  # 请求数据
        response.raise_for_status()  # 检查请求是否成功
        json_data = response.json()

        result = {
            'titles': [],
            'urls': [],
            'thumbnails': [],
            'up_authors': [],
            'durations': []  # 时长字段
        }

        if 'data' in json_data and json_data['data']['result']:
            for item in json_data['data']['result']:
                # 除了视频，还可能有直播等其他类型
                if item['result_type'] == 'video':
                    datas = item['data']
                    for data in datas:
                        if data['type'] == 'video':
                            # 使用 BeautifulSoup 提取纯文本
                            title = data.get('title', '未知标题')
                            clean_title = BeautifulSoup(title, "html.parser").get_text()

                            result['titles'].append(clean_title)

                            result['urls'].append(data.get('arcurl', ''))
                            # result['thumbnails'].append('https:' + data.get('pic', ''))  # 使用 'pic' 字段
                            result['durations'].append(data.get('duration', ''))
                            result['up_authors'].append(data.get('author', '未知UP主'))

        else:
            print("未找到数据或无视频结果")  # 调试信息

        return result

    except requests.exceptions.RequestException as e:
        print(f"请求异常: {e}")  # 输出异常信息
    except json.JSONDecodeError:
        print("JSON 解码错误")  # JSON 解析错误
    except Exception as e:
        print(f"发生错误: {e}")  # 处理其他异常

    return None