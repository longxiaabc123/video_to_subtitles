import json
import os

import requests
from bs4 import BeautifulSoup

# def getid():
#     url = "https://www.bilibili.com/video/BV1KX4geaEE9/?spm_id_from=333.1007.tianma.1-1-1.click&vd_source=b35b80b89f6098d9a96d1126f51d213e"
#
#     payload = {}
#     headers = {
#         'cookie': 'buvid3=49AC08E0-B714-D873-6123-DB579E52255D81540infoc; b_nut=1722217381; _uuid=7C108DE69-6268-75AD-10835-D10FA610F26FD782327infoc; buvid_fp=d6e0fab83f33c9b2bc79c2f11f68546b; enable_web_push=DISABLE; buvid4=4B068E3C-1B00-EA60-7A6A-45C09998AC0182822-024072901-gw97NB1d4%2F%2FXfsp5Ljf4Fg%3D%3D; header_theme_version=CLOSE; CURRENT_FNVAL=4048; rpdid=|(m)~|lmu|k0J\'u~kJlkJ|uJ; home_feed_column=5; browser_resolution=1920-911; DedeUserID=3461566668213005; DedeUserID__ckMd5=9410a637cff9a793; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3Mjg2MzQwMzUsImlhdCI6MTcyODM3NDc3NSwicGx0IjotMX0.k8gtCzbP4hZrNGJnETESGGOqR-VP2X8qXRE3wAG7F7Q; bili_ticket_expires=1728633975; b_lsid=10F8F9842_1926F70D8B5; bsource=search_google; SESSDATA=d53d921f%2C1743998522%2C80f72%2Aa1CjCePyNOQVdl9MzQNoTjIOVSvrGKDEsaaQxlQspZ-krDduDYLrvSrvXt5glh6abqbiESVmp5amVPV19hOFo2Z2Z1WkJoWjVZYXpadmNoeHlCb0F1Nm5WYnR4X3VPMUFlQU54LUVTbXhtd09kMExnNFZCeS12QWtBUTFMS0tVMlBuWDBTcTd5ZWNRIIEC; bili_jct=6c163e0ab30a0403687a76cfeeffad3f; sid=6eo5qo80; bmg_af_switch=1; bmg_src_def_domain=i0.hdslb.com; CURRENT_QUALITY=32; b_nut=1728454011; buvid3=A0518914-3BD1-15BC-6450-B1F0352A325811584infoc',
#         'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
#     }
#
#     response = requests.request("GET", url, headers=headers, data=payload)
#
#     soup = BeautifulSoup(response.text, 'html.parser')
#     scripts = soup.find_all('script')
#     for script in scripts:
#         if script.text.startswith('window.__INITIAL_STATE__'):
#
#             json_data = json.loads(script.text[25:-122])
#             print(json_data['aid'])
#             print(json_data['videoData']['cid'])
#             getjumpurl(json_data['aid'],json_data['videoData']['cid'])


def getjumpurl(aid,cid,save_path,video_title,list_title):
    url = "https://api.bilibili.com/x/player/wbi/v2?aid="+str(aid)+"&cid="+str(cid)+"&isGaiaAvoided=false"

    payload = {}
    headers = {
        'cookie': '''buvid3=41274A75-074F-B7E9-4E36-2A0C817023CD17891infoc; b_nut=1728143617; _uuid=ED7E9CDC-EFC3-10D63-445F-C9B56B6C1019818098infoc; buvid_fp=6f8cafb1fe23e3b3438d87d27ef6a0d3; enable_web_push=DISABLE; home_feed_column=5; browser_resolution=1528-746; buvid4=DD3B0A9C-2D8E-D87F-CBB6-C1153D4F2FE719693-024100515-PxaXIe7uZiMjJrRqm4rA6g%3D%3D; SESSDATA=d812e28c%2C1743695663%2Cb38ed%2Aa1CjDdYN_px8XPQPQTp0Hac99woVXwumnoT3hHo7DO52z9C9JThDCNY95n4omEBUdLLUYSVjdrWFozbmZpX0dqWXFWbGphcnVsREhFZGlYak0tN0dsZDlxNnVOVUFMdG9VNEpnYW5OTldTU1AxRzNiSkRfeDhreldGRGR5SHBPaVF6Z1E5Q0tBdU53IIEC; bili_jct=11d4f2cd0ff6195fc14587465af21d22; DedeUserID=543527307; DedeUserID__ckMd5=4322a398c554b6a3; header_theme_version=CLOSE; bp_t_offset_543527307=984892411073265664; CURRENT_BLACKGAP=0; bsource=search_bing; CURRENT_FNVAL=4048; rpdid=|(umk~uYml)~0J'u~k)km)muY; sid=59n3ezbf; b_lsid=8F5BC810C_19280E66A8A; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3Mjg5OTg2MzgsImlhdCI6MTcyODczOTM3OCwicGx0IjotMX0.LSt3m3yKDVkbLN5eNacqRuubDdAzJQmMySCld7R5cvw; bili_ticket_expires=1728998578''',
        'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'

    }

    response = requests.request("GET", url, headers=headers, data=payload)

    json_data = json.loads(response.text)
    subtitles = json_data['data']['subtitle']['subtitles']
    for subtitle in subtitles:
        if '中文' in subtitle['lan_doc']:
            jump_url = 'https:' + subtitle['subtitle_url']
            print(jump_url)
            if list_title is None:
                get_subtitle(jump_url,save_path,video_title)
            else:
                get_subtitle_list(jump_url,save_path,video_title,list_title)


def float2hhmmss(num):
    int_ = int(num)
    frac = int((num - int_) * 1000)
    hr, min_, sec = int_ // 3600, int_ % 3600 // 60, int_ % 60
    return f'{hr}:{min_:02d}:{sec:02d}.{frac:03d}'

def bilisub2srt(j):
    subs = j['body']

    srts = []
    for i, sub in enumerate(subs, start=1):
        st = float2hhmmss(sub['from'])
        ed = float2hhmmss(sub['to'])
        txt = sub['content']
        srtpt = f'{i}\n{st} --> {ed}\n{txt}'
        srts.append(srtpt)

    srt = '\n\n'.join(srts)
    return srt


def get_subtitle(url,save_path,video_title):

    payload = {}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)

    # print(response.text)
    json_data = json.loads(response.text)
    srt = bilisub2srt(json_data)
    # print(srt)

    with open(save_path + '\\' + video_title + '.txt','w',encoding='utf-8')as f:
        f.write(srt)
    print("字幕输出成功！！——————> " + save_path + '\\' + video_title + '.txt')


def get_subtitle_list(url, save_path, video_title,list_title):
    payload = {}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)

    # print(response.text)
    json_data = json.loads(response.text)
    srt = bilisub2srt(json_data)
    # print(srt)
    output_folder_path = save_path + '\\' + list_title
    os.makedirs(output_folder_path, exist_ok=True)
    with open(output_folder_path+ "\\" + video_title + '.txt', 'w', encoding='utf-8') as f:
        f.write(srt)
    print("字幕输出成功！！——————> " + output_folder_path+ "\\" + video_title + '.txt')

# getid()
# getjumpurl('203821664','287962381')