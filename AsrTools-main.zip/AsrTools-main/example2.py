# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup


# 获取每集视频的名字
def fin_data(_url):
    """
        获取每集视频的名字
    :param _url: 要爬取的网页链接
    :return:   网页标题, {每集的名字:每集的时长}
    """
    # 设置请求头信息
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.50"
    }

    get_url = requests.get(url=_url, headers=headers)  # 此处不添加请求头，也可以正常爬取
    # print(get_url.text)                                        # 查看获取网页的源码--测试用

    soup1 = BeautifulSoup(get_url.text, "html.parser")  # 用html.parser解析器
    _url_title = soup1.title.string  # 获取标题
    a = soup1.findAll(name="div", attrs={"class": "video-episode-card"})  # 每集名字所在的div

    _video_dict = {}  # 存放每集的信息

    for ii in a:
        # print(i)
        # 获取每集的名字
        bv_title_ = ii.find(name="div", attrs={"class": "video-episode-card__info-title"})
        bv_title = bv_title_.get_text().replace('\n', '').replace(' ', '')

        # 获取每集的时长
        bv_time_ = ii.find(name="div", attrs={"class": "video-episode-card__info-duration"})
        bv_time = str(bv_time_.string).replace('\n', '').replace(' ', '')

        _video_dict[bv_title] = bv_time
        # print('-----------')

    # print(_bv_dict)
    return _url_title, _video_dict


# 保存文件
def save(_url_title, _video_dict):
    """
        保存文件
    :param _url_title: 网页标题
    :param _video_dict: {每集的名字:每集的时长}
    :return:
    """
    file_title = str(_url_title) + ".txt"  # 合成.txt格式 文件名
    name_file = open(file_title, "w", encoding="utf-8")  # 写入文件

    for ii in _video_dict:
        name_file.write(ii + "\n")

    name_file.close()


if __name__ == '__main__':
    url = 'https://www.bilibili.com/video/BV1fh411y7R8/?spm_id_from=333.337.search-card.all.click&vd_source=b35b80b89f6098d9a96d1126f51d213e'  # 要爬取的网页
    url_title, video_dict = fin_data(url)

    # 遍历列表
    for i in video_dict:
        print(i)

    # save(url_title, video_dict)
