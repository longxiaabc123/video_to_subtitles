import requests
import re
from bs4 import BeautifulSoup

global url_title
# 创建正则表达式对象，表示规则
findLink = re.compile(r'"part":"(.*?)","duratio')


# 获取网页数据，传入参数：网址
def find_data(_url):
      # 此处不添加请求头，也可以正常获取
    headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'cookie': 'buvid3=41274A75-074F-B7E9-4E36-2A0C817023CD17891infoc; b_nut=1728143617; _uuid=ED7E9CDC-EFC3-10D63-445F-C9B56B6C1019818098infoc; buvid_fp=6f8cafb1fe23e3b3438d87d27ef6a0d3; enable_web_push=DISABLE; buvid4=DD3B0A9C-2D8E-D87F-CBB6-C1153D4F2FE719693-024100515-PxaXIe7uZiMjJrRqm4rA6g%3D%3D; SESSDATA=d812e28c%2C1743695663%2Cb38ed%2Aa1CjDdYN_px8XPQPQTp0Hac99woVXwumnoT3hHo7DO52z9C9JThDCNY95n4omEBUdLLUYSVjdrWFozbmZpX0dqWXFWbGphcnVsREhFZGlYak0tN0dsZDlxNnVOVUFMdG9VNEpnYW5OTldTU1AxRzNiSkRfeDhreldGRGR5SHBPaVF6Z1E5Q0tBdU53IIEC; bili_jct=11d4f2cd0ff6195fc14587465af21d22; DedeUserID=543527307; DedeUserID__ckMd5=4322a398c554b6a3; header_theme_version=CLOSE; bp_t_offset_543527307=984892411073265664; CURRENT_BLACKGAP=0; bsource=search_bing; CURRENT_FNVAL=4048; rpdid=|(umk~uYml)~0J\'u~k)km)muY; sid=59n3ezbf; b_lsid=F4F52E38_1928242F64E; home_feed_column=4; browser_resolution=711-746; bili_ticket=eyJhbGciOiJIUzI1NiIsImtpZCI6InMwMyIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MjkwMjM4MDksImlhdCI6MTcyODc2NDU0OSwicGx0IjotMX0.jr31cTQJcAIkJHbkX9WbpjrAyZHtc6KxQooSkk2scqs; bili_ticket_expires=1729023749; sid=qi0j2095',
        'origin': 'https://search.bilibili.com',
        'priority': 'u=1, i',
        'referer': 'https://search.bilibili.com/all?keyword=%E8%80%81%E9%AB%98%E4%B8%8E%E5%B0%8F%E8%8C%89%E6%9C%80%E6%96%B0&search_source=1',
        'sec-ch-ua': '"Microsoft Edge";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0'
    }


    get_url = requests.request("GET", url, headers=headers)                                   # 查看获取网页的源码--测试用

    bs_html = BeautifulSoup(get_url.text, "html.parser")  # 用html.parser解析器

    global url_title
    url_title = bs_html.title.string  # 获取标题

    bs_find_data = bs_html.select('script')  # 获取标签树

    bs_data = ''

    # 筛选列表数据
    for __i in bs_find_data:
        bs_data = str(__i)
        if 'window.__INITIAL_STATE__={' in bs_data:
            # print(bs_data)                                     # 查看筛选的数据--测试用
            break

    # 正则查找，返回列表
    re_list = re.findall(findLink, bs_data)
    # print(re_list)                                             # 查看返回的列表--测试用

    return re_list


# 保存文件，传入参数：find_data() 返回的列表
def save(__video_list):
    file_title = str(url_title) + ".txt"  # 合成.txt格式 文件名
    name_file = open(file_title, "w", encoding="utf-8")  # 写入文件

    for __i in video_list:
        name_file.write(__i + "\n")

    name_file.close()


if __name__ == '__main__':
    url = 'https://www.bilibili.com/video/BV1fh411y7R8/?spm_id_from=333.337.search-card.all.click&vd_source=b35b80b89f6098d9a96d1126f51d213e'
    video_list = find_data(url)

    # 遍历列表，查看每集名字
    for i in video_list:
        print(i)

    save(video_list)

